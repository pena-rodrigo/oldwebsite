# frozen_string_literal: true

module Liquid
  module Usage
    def self.increment(name)
    end
  end
end
